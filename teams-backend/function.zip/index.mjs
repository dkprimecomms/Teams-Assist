import { createRemoteJWKSet, jwtVerify } from "jose";

const TENANT_ID = process.env.TENANT_ID;
const CLIENT_ID = process.env.CLIENT_ID;

const ISSUER = `https://login.microsoftonline.com/${TENANT_ID}/v2.0`;
const JWKS = createRemoteJWKSet(
  new URL(`https://login.microsoftonline.com/${TENANT_ID}/discovery/v2.0/keys`)
);

export const handler = async (event) => {
  try {
    const auth =
      event.headers?.authorization || event.headers?.Authorization || "";

    if (!auth.startsWith("Bearer ")) {
      return {
        statusCode: 401,
        body: JSON.stringify({ error: "Missing bearer token" })
      };
    }

    const token = auth.slice(7);

    const { payload } = await jwtVerify(token, JWKS, {
      issuer: ISSUER,
      audience: CLIENT_ID
    });

    return {
      statusCode: 200,
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        ok: true,
        upn: payload.preferred_username,
        oid: payload.oid,
        tid: payload.tid,
        aud: payload.aud
      })
    };
  } catch (e) {
    return {
      statusCode: 401,
      body: JSON.stringify({ error: e.message })
    };
  }
};
